config.logger = Logger.new(STDOUT)
