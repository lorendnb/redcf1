--------------------------------------------------------------------------------
-- Rec�lculo Saldos Argencard / LINK
--------------------------------------------------------------------------------
-- SELECT * FROM LNK501 WHERE IFNULL(FlagGAEnt,FALSE)=TRUE ORDER BY CodgMarca
-- SELECT * FROM LNK512 WHERE FECHPRESN > '2017-06-21'
-- SELECT * FROM LNK512 WHERE FECHPRESN > '2017-06-21' AND Importe<>0
-- SELECT TipoMovim, Count(*) FROM LNK512 WHERE FECHPRESN > '2017-06-21' GROUP BY TipoMovim
-- SELECT * FROM LNK512 WHERE FECHPRESN > '2017-06-20' AND Importe<>0 AND CodgMarca>'02' ORDER BY CodgMarca, FechOprcn, HoraOprcn

----------------------
DECLARE Saldos CURSOR;
DECLARE Movims CURSOR;
DECLARE Saldo  Numeric(12,2);

OPEN Saldos AS SELECT * FROM LNK501 WHERE IFNULL(FlagGAEnt,FALSE)=TRUE ORDER BY CodgMarca;
WHILE FETCH Saldos DO

  OPEN Movims AS SELECT * FROM LNK512 WHERE CodgMarca=Saldos.CodgMarca AND FECHPRESN>'2018-02-20' AND Importe<>0 ORDER BY FechOprcn, HoraOprcn;
  IF FETCH Movims THEN
    IF Movims.TipoMovim='APERT' THEN
      Saldo = Movims.Importe;  	 
      WHILE FETCH Movims DO
        IF Movims.TipoMovim IN ('DEPO','AJST','ADEL','RADEL','CFAR','RCFAR') THEN
		  Saldo = Saldo - Movims.Importe;
		ELSE
          IF Movims.TipoMovim IN ('APERT','CIERR') THEN
            UPDATE LNK512 SET Importe = Saldo, UserLU='crf' 
              WHERE CodgMarca = Movims.CodgMarca 
			  AND FechOprcn = Movims.FechOprcn AND HoraOprcn = Movims.HoraOprcn
			  AND TipoMovim IN ('APERT','CIERR');  
            IF Movims.TipoMovim IN ('APERT') AND Movims.FechPresn=Saldos.FechPresn THEN
	          UPDATE LNK501 SET SaldAprtr = Saldo WHERE CodgMarca = Saldos.CodgMarca;
            END;
		  END;
		END;
	  END;
	  UPDATE LNK501 SET SaldActul = Saldo WHERE CodgMarca = Saldos.CodgMarca;
	  Saldo = 0;
	END;
  END;
  CLOSE Movims;
  
END;
CLOSE Saldos; 	    
-- SUCCESS: 612 Rows Affected - OF
-- SUCCESS: 612 Rows Affected - ON
-- SUCCESS: 1188 Rows Affected
